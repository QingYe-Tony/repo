

if (typeof use12hours === 'undefined') { var use12hours = false; }
if (typeof disablebgeffects === 'undefined') {  var disablebgeffects = false;}
if (typeof usebgimg === 'undefined') { var usebgimg = true; }
if (typeof hideseconds === 'undefined') { var hideseconds = false; }


const data = [ 0x77,   0x24,   0x5d,   0x6d,   0x2e,   0x6b,   0x7b,   0x27,   0x7f,   0x6f,   0x00 ];

function displayNum(id, num){
  var dat = data[num];
  for ( var i=0; i<7; i++ ){
    var line = $('#num'+id+'>.line'+(i+1));

    if (dat & (1<<i)) {
      line.addClass('on');
    } else {
      line.removeClass('on');
    }

  }
}
var updateTime = function () {

  var date = new Date();
  var h = date.getHours();
  var m = date.getMinutes();
  var s = date.getSeconds();

  if (use12hours) {
    h = h % 12;
  }

  var h1 = ~~(h / 10);
  var m1 = ~~(m / 10);
  var s1 = ~~(s / 10);
  var h2 = h - 10 * h1;
  var m2 = m - 10 * m1;
  var s2 = s - 10 * s1;

  // if (h1 == 0) { h1 = 10; }

  displayNum(1, h1);
  displayNum(2, h2);
  displayNum(3, m1);
  displayNum(4, m2);

  if (!hideseconds) {
    displayNum(5, s1);
    displayNum(6, s2);
  }
}


setInterval(updateTime, 1000);
$(function () {
  if (usebgimg) {
    $("body").css({ "background": "url('bg.png')" });
  }
  if (hideseconds) {
    $('#colon2,#num5,#num6').hide();
  }
  if (disablebgeffects) {
    $('#particles-js').hide();
  }
});
