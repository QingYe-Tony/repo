
if (typeof disablebgeffects === 'undefined') { var disablebgeffects = false; }
if (typeof usebgimg === 'undefined') { var usebgimg = false; }

setInterval(function(){

  var date = new Date();
  var h = date.getHours();
  var m = date.getMinutes();
  var s = date.getSeconds();

  $('#hour').css( { transform: "rotate("+((h+m/60)/12*360)+"deg)" } );

  $('#min').css( { transform: "rotate("+(m/60*360)+"deg)" }  );

  $('#sec').css( { transform: "rotate("+(s/60*360)+"deg)" });

}, 1000);

$(function () {
  if (usebgimg) {
    $("body").css({ "background": "url('bg.png')" });
  }
  if (disablebgeffects) { $("#particles-js").hide(); }
})
