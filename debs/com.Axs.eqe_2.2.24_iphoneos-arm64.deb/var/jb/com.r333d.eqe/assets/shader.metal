#include <metal_stdlib>

using namespace metal;

constant float4x4 IDENTITY_MATRIX = float4x4(
    1, 0, 0, 0,
    0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1);

constant float PI = 3.14159265358979323846264;

constexpr sampler SAMPLER_NEAREST (mag_filter::nearest,
                                   min_filter::nearest);

constexpr sampler SAMPLER_LINEAR (mag_filter::linear,
                                   min_filter::linear);

struct Uniforms
{
    float3 rotation;
    float aspectRatio;
    float3 prepos;
    float3 postpos;
};

struct FragmentUniforms
{
    int coefsCount;
    int fftCount;
    float yOffset;
    int randomseed;
    bool loading;
};

struct VertexIn
{
    float4 position;
    float4 color;
    float2 uv;
};

struct VertexOut
{
    float4 position [[position]];
    float4 color;
    float2 uv;
};

float cantorPairing(float x, float y) {
    float z = (x + y) * (x + y + 1) / 2.0 + y;

    // Normalize the result to be between 0 and 1
    float maxVal = 2.0;
    return z / ((maxVal * (maxVal + 1)) / 2.0 + 1.0);
}

// https://developer.apple.com/library/archive/samplecode/MetalShaderShowcase/Listings/MetalShaderShowcase_AAPLWoodShader_metal.html
// Generate a random float in the range [0.0f, 1.0f] (based on the xor128 algorithm)
float rand(int seed) {
    seed = (seed<< 13) ^ seed;
    return 1.0 - ((seed*seed*seed*15731 + seed*789221 + 1376312589) & 2147483647) / 1073741824.0f / 2.0f;
}

float clamp01(float in) {
    return clamp(in, 0.0, 1.0);
}

float4x4 translate(float x, float y, float z) {
    return float4x4(
        1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        x, y, z, 1);
}

float4x4 rotate(float x, float y, float z) {
    float c, s;

    c = cos(x);
    s = sin(x);
    float4x4 rotX = float4x4(
        1, 0, 0, 0,
        0, c,-s, 0,
        0, s, c, 0,
        0, 0, 0, 1);

    c = cos(y);
    s = sin(y);
    float4x4 rotY = float4x4(
        c, 0, s, 0,
        0, 1, 0, 0,
       -s, 0, c, 0,
        0, 0, 0, 1);

    c = cos(z);
    s = sin(z);
    float4x4 rotZ = float4x4(
        c,-s, 0, 0,
        s, c, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1);

    return rotZ * rotY * rotX;
}

float4x4 scale(float x, float y, float z)
{
    return float4x4(
        x, 0, 0, 0,
        0, y, 0, 0,
        0, 0, z, 0,
        0, 0, 0, 1);
}

float4x4 perspective(float fovY, float aspect, float nearZ, float farZ) {
    float yscale = 1 / tan(fovY * 0.5);
    float xscale = yscale / aspect;
    float q = farZ / (farZ - nearZ);

    return float4x4(
        xscale, 0, 0, 0,
        0, yscale, 0,  0,
        0, 0, q, 1,
        0, 0, -q * nearZ, 0);
}

vertex VertexOut vertexFunction(
    device VertexIn *vertices [[buffer(0)]],
    constant Uniforms &uniforms [[buffer(1)]],
    uint vid [[vertex_id]])
{
    float4x4 transform = IDENTITY_MATRIX;
    transform = transform * translate(uniforms.prepos.x, uniforms.prepos.y, uniforms.prepos.z);
    transform = transform * rotate(uniforms.rotation.x, uniforms.rotation.y, uniforms.rotation.z);
    transform = transform * translate(uniforms.postpos.x, uniforms.postpos.y, uniforms.postpos.z);
    float farZ = 10 * (abs(uniforms.prepos.z) + abs(uniforms.postpos.z));
    transform = perspective(PI/4, uniforms.aspectRatio, 0.1, farZ) * transform;

    VertexOut out;
    out.position = transform * vertices[vid].position;
    out.color = vertices[vid].color;
    out.uv.x = vertices[vid].uv.x;
    out.uv.y = vertices[vid].uv.y;
    if(out.uv.x < 0) {
        out.uv.x = 1 + out.uv.x;
    }
    if(out.uv.y < 0) {
        out.uv.y = 1 + out.uv.y;
    }
    out.uv.y = 1 - out.uv.y;
    return out;
}

fragment float4 fragmentFunction(
    VertexOut in [[stage_in]],
    texture2d<float> texture [[texture(0)]],
    constant FragmentUniforms &fragmentUniforms [[buffer(0)]],
    constant float *coefs [[buffer(1)]],
    constant float *fft [[buffer(2)]])
{
    float4 sample = texture.sample(SAMPLER_LINEAR, in.uv);
    if(fragmentUniforms.loading) {
        float r = rand(fragmentUniforms.randomseed + int(100000 * cantorPairing(in.uv.x, in.uv.y)));
        return .2*sample + .8*float4(r, r, r, 1);
    } else {
        return sample;
    }
}

vertex VertexOut freqVertexFunction(
    device VertexIn *vertices [[buffer(0)]],
    constant Uniforms &uniforms [[buffer(1)]],
    uint vid [[vertex_id]])
{
    float4x4 transform = IDENTITY_MATRIX * scale(2, 2, 1);

    VertexOut out;
    out.position = transform * vertices[vid].position;
    out.uv = float2(vertices[vid].position.x + 0.5, 1 - (vertices[vid].position.y + 0.5));
    return out;
}

fragment float4 freqFragmentFunction(
    VertexOut in [[stage_in]],
    texture2d<float> texture [[texture(0)]],
    constant FragmentUniforms &fragmentUniforms [[buffer(0)]],
    constant float *coefs [[buffer(1)]],
    constant float *fft [[buffer(2)]])
{
    if(fragmentUniforms.coefsCount == 0) {
        float rgb = rand(fragmentUniforms.randomseed + int(100000 * cantorPairing(in.uv.x, in.uv.y)));
        return 0.5 * float4(rgb, rgb, rgb, 0);
    }
    float w = exp(log(1000.0)*in.uv.x)/1000.0;
    float phi = pow(sin(w*PI/2), 2);
    float y = 0;
    for(int i = 0; i < fragmentUniforms.coefsCount; i++) {
        float b0 = coefs[0 + i*5];
        float b1 = coefs[1 + i*5];
        float b2 = coefs[2 + i*5];
        float a0 = 1;
        float a1 = coefs[3 + i*5];
        float a2 = coefs[4 + i*5];
        y += log(pow(b0+b1+b2, 2) - 4*(b0*b1 + 4*b0*b2 + b1*b2)*phi + 16*b0*b2*phi*phi);
        y -= log(pow(a0+a1+a2, 2) - 4*(a0*a1 + 4*a0*a2 + a1*a2)*phi + 16*a0*a2*phi*phi);
    }
    float fftDist = 0;
    if(fragmentUniforms.fftCount != 0) {
        int idx = (int)(w * fragmentUniforms.fftCount/2 + 0.5);
        float fftY = fft[idx];
        float freq = (idx + 0.5) * 44100 / fragmentUniforms.fftCount;
        fftY = fftY * // a-weighting
            12200.0*12200.0*pow(freq, 4)
            /(  (freq*freq + 20.6*20.6)
                *(freq*freq + 12200.0*12200.0)
                *sqrt((freq*freq + 107.7*107.7)*(freq*freq + 737.9*737.9))
            );
        fftDist = in.uv.y - 1 + fftY/32;
    }
    float dist = in.uv.y - fragmentUniforms.yOffset + y/16;
    float r = 0;
    float g = 0;
    float white = 0;
    float scale = 20;
    if(dist > 0 || fftDist > 0) {
        float scaledY = y*10/log(10.0)/scale + 0.5;
        float alpha;
        if(fftDist > 0) {
            alpha = 0.25;
        } else {
            alpha = pow(clamp01(1 - dist*10), 10);
        }
        r = alpha * clamp01(scaledY*2);
        g = alpha * clamp01((1-scaledY)*2);
    }
    return float4(r + white, g + white, white, 0);
}
